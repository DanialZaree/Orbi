const mongoose = require("mongoose");

// A sub-schema for a single block of content (text, code, or image)
const contentBlockSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
      enum: ["text", "code", "image", "video", "file"],
    },
    value: {
      type: String,
      required: true,
    },
    language: {
      type: String,
      required: false,
    },
    fileName: {
      type: String,
      required: false,
    },
  },
  { _id: false },
);

// The schema for a single message in a chat
const messageSchema = new mongoose.Schema(
  {
    role: {
      type: String,
      required: true,
      enum: ["user", "assistant"],
    },
    content: [contentBlockSchema],
    geminiParts: {
      type: [mongoose.Schema.Types.Mixed],
      required: false,
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
  }
);

// The main chat schema with the userId type corrected
const chatSchema = new mongoose.Schema(
  {
    userId: {
      // --- FIX: Changed type from ObjectId to String to match existing database data ---
      type: String,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    messages: [messageSchema],
  },
  {
    timestamps: true,
  },
);

// optimize query performance for fetching chat history
chatSchema.index({ userId: 1, updatedAt: -1 });

module.exports = mongoose.model("Chat", chatSchema);
